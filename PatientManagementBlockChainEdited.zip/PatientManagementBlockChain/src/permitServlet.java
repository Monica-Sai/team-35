

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class permitServlet
 */
@WebServlet("/permitServlet")
public class permitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public permitServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String addUserId=request.getParameter("user_auth");
		String currUserId=request.getParameter("cur_user");
		Connection con=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/opendata","root","");
			String smt="Insert into authlist values(?,?);";
			PreparedStatement ps=con.prepareStatement(smt);
			ps.setString(1,currUserId);
			ps.setString(2,addUserId);
			ps.execute();
			con.close();
			response.sendRedirect("Dashboard.html");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
