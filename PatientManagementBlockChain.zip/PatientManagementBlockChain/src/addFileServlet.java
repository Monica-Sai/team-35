import ChainDef.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.sql.rowset.serial.SerialBlob;


/**
 * Servlet implementation class addFileServlet
 */
@WebServlet("/addFileServlet")
public class addFileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addFileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con=null;
		String username=request.getParameter("cur_user");
		ServletInputStream sis = request.getInputStream();
        byte[] b = new byte[request.getContentLength()];
        sis.read(b,0,b.length);
		try
		{
			Blob bl=new SerialBlob(b);
			System.out.println(bl);
			String tempdel=new String(b);
			System.out.println("mmama"+tempdel);
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+username,"root","");
			PreparedStatement pps=con.prepareStatement("Select * from filedata ORDER BY pat_id DESC LIMIT 1");
			ResultSet rss=pps.executeQuery();
			String prevhash="";
			if(rss.next())
			{
				prevhash=rss.getString("hash");
			}
			String datastr=new String(b);
			datastr=username+datastr+prevhash;
			Block blk=new Block(datastr);
			String curhash=blk.getHash();
			PreparedStatement ps=con.prepareStatement("Insert into filedata values(?,?,?,?,?)");
			ps.setString(1,username);
			ps.setBlob(2,bl);
			ps.setTimestamp(3,new Timestamp(System.currentTimeMillis()));
			ps.setString(4,prevhash);
			ps.setString(5,curhash);
			ps.execute();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		response.sendRedirect("Dashboard.html");
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
