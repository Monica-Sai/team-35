
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    static boolean check(String s,HttpServletResponse response) throws ServletException, IOException
    {
    	try {
    	Class.forName("com.mysql.jdbc.Driver");
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/opendata","root","");
    	String que="select * from credentials where username=?;";
    	PreparedStatement ps=con.prepareStatement(que);
    	ps.setString(1,s);
    	ResultSet rs=ps.executeQuery();
    	if(rs.next()==false)
    	{
    		con.close();
    		return true;
    	}
    	con.close();
    	return false;
    	}
    	catch(Exception e)
    	{
    		response.sendRedirect("Register.html");
    	}
		return false;
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		String dob=request.getParameter("mail");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		Connection con=null;
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","");
			System.out.println("connection to local host established");
			if(check(username,response))
			{
				//System.out.println("inside check block");
				Statement smtt=con.createStatement();
				String qwe="CREATE DATABASE "+username+";";
				smtt.executeUpdate(qwe);
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+username,"root","");
PreparedStatement table=con.prepareStatement("Create table filedata(pat_id varchar(80),filedata BLOB,timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,prevhash text,hash text)");
				table.execute();
				//System.out.println("DB created");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/opendata","root","");
				PreparedStatement smt=con.prepareStatement("Insert into credentials values(?,?,?);");
				smt.setString(1,username);
				smt.setString(2,username);
				smt.setString(3,password);
				smt.execute();
				//System.out.println("values inserted to credentials");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/opendata","root","");
				smt=con.prepareStatement("Insert into details values(?,?,?);");
				smt.setString(1,name);
				smt.setString(2,username);
				smt.setString(3,dob);
				smt.execute();
				con.close();
				response.sendRedirect("Login.html");
			}
			else
			{
				response.sendRedirect("Register.html");
				//System.out.println("inside else block");
				//return to register page with msg as username already exists.
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
