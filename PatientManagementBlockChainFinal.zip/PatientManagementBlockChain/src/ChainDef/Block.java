package ChainDef;

import java.util.Date;

import ChainDef.StringUtil;
import PatientDef.Patient;
public class Block {
	private String Data;
	private String Hash;
	public Block(String Data)
	{
		this.Data=Data;
		setHash();
	}
	public void setHash()
	{
		Hash=StringUtil.applySha256(Data);
	}
	public String getHash()
	{
		return Hash;
	}
}
