

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class viewServlet
 */
@WebServlet("/viewServlet")
public class viewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		String user1=request.getParameter("cur_user");
		String user2=request.getParameter("user_auth");
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/opendata","root","");
			PreparedStatement ps=con.prepareStatement("Select authid from authlist where pat_id=? ;");
			ps.setString(1,user1);
			ResultSet rs=ps.executeQuery();
			int flag=0;
			if(user1.equals(user2))
			{
				System.out.println("same inputs work");
				flag=1;
			}
			while(rs.next())
			{
				String temp=rs.getString(1);
				if(temp.equals(user2))
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+user2,"root","");
				ps=con.prepareStatement("Select filedata from filedata");
				rs=ps.executeQuery();
				System.out.println("data is here");
				pw.println("<html><p>data is below</p><table>");
				while(rs.next())
				{
					System.out.println("entered to read file");
					Blob lastName = rs.getBlob(1);
					System.out.println(lastName);
					byte[] blobAsBytes = lastName.getBytes(1,(int)lastName.length());
					String datawrite=new String(blobAsBytes);
		            pw.println("<p>" +datawrite + "</p>");
				}
				pw.println("</table></html>");
		        con.close();
			}
			else
			{
				
				System.out.println("No Data to Show");
				response.sendRedirect("Dashboard.html");
				response.getWriter().append("No Data Available to Show\n ");
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
