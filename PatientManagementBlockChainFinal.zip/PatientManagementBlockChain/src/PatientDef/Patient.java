package PatientDef;

public class Patient {

}
